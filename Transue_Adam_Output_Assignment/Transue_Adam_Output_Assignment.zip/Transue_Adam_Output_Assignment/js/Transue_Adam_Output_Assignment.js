/**
 Adam Transue
 SDI 1510
 Creating Variables and Output
 **/

//Variables will go here
var numberOfKids = 1;  //Number of variable
var daughtersName = "Drew";  // String variable
var placeOfEmployment = "Monroe County 911 center";  // string variable
var havePreviousProgramingExperiance = true;   // boolean variable
var dutysOfEmployment = "I work as a 911 dispatcher and call taker, answering the phone and dispatching the necessary authority\'s";   //String variable


//outputs will reside here
console.log("I have a total of " + numberOfKids  + " kids.");  // use of a number value
console.log("My beautiful daughters name is " + daughtersName + "."); // use of a string value
console.log("I am currently employed by the " + placeOfEmployment + "."); // use of a string value
console.log("While at work my job duties include " + dutysOfEmployment + "."); // use of a string value
console.log("Do I have any previous programming experiance? " + havePreviousProgramingExperiance); //use of a boolean value

